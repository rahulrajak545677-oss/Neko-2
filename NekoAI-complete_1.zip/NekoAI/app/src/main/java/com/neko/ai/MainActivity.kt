package com.neko.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NekoApp() }
    }
}

/** Order: Overlay, Reader (accessibility), Capture (rides on Reader, Android 11+), Mic. */
private fun readPerms(ctx: Context): List<Boolean> {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
    val reader = enabled?.contains(ctx.packageName) == true
    return listOf(
        Settings.canDrawOverlays(ctx),
        reader,
        reader && Build.VERSION.SDK_INT >= 30,
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    )
}

@Composable
fun NekoApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("neko", Context.MODE_PRIVATE) }
    val s = remember { NekoSettings(prefs) }
    var on by remember { mutableStateOf(prefs.getBoolean("on", false)) }
    var perms by remember { mutableStateOf(readPerms(ctx)) }
    var sheet by remember { mutableStateOf<String?>(null) }
    var tryOpen by remember { mutableStateOf(false) }
    val svc = Intent(ctx, BubbleService::class.java)

    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perms = readPerms(ctx) }
    // After Mic is allowed, restart the bubble service so it can use the microphone.
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        perms = readPerms(ctx)
        if (granted && on) { ctx.stopService(svc); ContextCompat.startForegroundService(ctx, svc) }
    }
    fun overlaySettings() = ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        perms = readPerms(ctx)
        if (on && !perms[0]) { on = false; prefs.edit().putBoolean("on", false).apply(); ctx.stopService(svc) }
    }
    BackHandler(enabled = tryOpen) { tryOpen = false }

    NekoHome(
        s, on, perms,
        onPower = {
            when {
                !perms[0] -> { Toast.makeText(ctx, "Allow “Display over other apps” first", Toast.LENGTH_SHORT).show(); overlaySettings() }
                !on && Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED ->
                    ask.launch(Manifest.permission.POST_NOTIFICATIONS)
                else -> {
                    on = !on
                    prefs.edit().putBoolean("on", on).apply()
                    if (on) ContextCompat.startForegroundService(ctx, svc) else ctx.stopService(svc)
                }
            }
        },
        onPerm = { i ->
            when (i) {
                0 -> overlaySettings()
                1 -> ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                2 -> if (Build.VERSION.SDK_INT >= 30) ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                     else Toast.makeText(ctx, "Screen capture needs Android 11 or newer", Toast.LENGTH_LONG).show()
                3 -> askMic.launch(Manifest.permission.RECORD_AUDIO)
                else -> {}
            }
        },
        onGrantAll = {
            // One step at a time; come back and tap again for the next one.
            when {
                !perms[0] -> { Toast.makeText(ctx, "Step 1: allow Display over other apps", Toast.LENGTH_SHORT).show(); overlaySettings() }
                !perms[3] -> askMic.launch(Manifest.permission.RECORD_AUDIO)
                !perms[1] -> {
                    Toast.makeText(ctx, "Last step: turn on Neko AI in Accessibility", Toast.LENGTH_LONG).show()
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                else -> Toast.makeText(ctx, "All set! Tap the cat to wake Neko", Toast.LENGTH_SHORT).show()
            }
        },
        onOpen = { k -> if (k == "try") tryOpen = true else sheet = k }
    )

    when (sheet) {
        "bubble" -> BubbleLookSheet(s, onCatStyle = { sheet = "cat" }) { sheet = null }
        "cat" -> CatStyleSheet(s) { sheet = "bubble" }
        "brain" -> AiBrainSheet(s) { sheet = null }
        "smart" -> SmartSheet(s) { sheet = null }
        "apps" -> AppControlSheet(s) { sheet = null }
        "privacy" -> PrivacySheet(s) { sheet = null }
    }
    if (tryOpen) TryNeko(s) { tryOpen = false }
}
