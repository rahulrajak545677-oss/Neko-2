package com.neko.ai

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------- shared building blocks ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NekoSheet(title: String, onDone: () -> Unit, scroll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDone, containerColor = Color(0xFF120B22),
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)
                .then(if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.Close, "Close", tint = Color.White, modifier = Modifier.clip(CircleShape).clickable(onClick = onDone).padding(8.dp))
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun Panel(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(shape).background(Color(0x0DFFFFFF)).border(1.dp, Color(0x1AFFFFFF), shape).padding(14.dp)) {
        if (title != null) { Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(10.dp)) }
        content()
    }
}

@Composable
private fun Pill(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).background(if (selected) accent else Color(0x14FFFFFF)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(label, color = if (selected) Ink else Color.White, fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) }
}

@Composable
private fun PillRow(options: List<String>, selected: String, accent: Color, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o -> Pill(o, o == selected, accent) { onPick(o) } }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Switch(
            checked, onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = accent,
                uncheckedThumbColor = Muted, uncheckedTrackColor = Color(0x22FFFFFF), uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, accent: Color, onChange: (Float) -> Unit) {
    Text(label, color = Muted, fontSize = 13.sp)
    Slider(value, onChange, valueRange = range, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = Color(0x22FFFFFF)))
}

@Composable
private fun fieldColors(accent: Color) = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = accent, unfocusedBorderColor = Color(0x55FFFFFF),
    focusedLabelColor = accent, unfocusedLabelColor = Muted, cursorColor = accent
)

// ---------- Bubble look ----------

@Composable
fun BubbleLookSheet(s: NekoSettings, onCatStyle: () -> Unit, onDone: () -> Unit) {
    val accent = s.currentSkin.edge
    NekoSheet("Bubble look", onDone) {
        Panel {
            Row(Modifier.fillMaxWidth().clickable(onClick = onCatStyle), verticalAlignment = Alignment.CenterVertically) {
                CatFace(true, s.currentSkin.hue, Modifier.size(width = 46.dp, height = 40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Cat style", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("${Cfg.moods[s.mood]} · ${Cfg.personas[s.persona]} · ${s.currentSkin.name}", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
            }
        }
        Panel {
            SliderRow("Bubble size · ${s.size} dp", s.size.toFloat(), 40f..96f, accent) { s.size = it.toInt() }
        }
        Panel("Start corner") {
            PillRow(Cfg.corners, Cfg.corners[s.corner.coerceIn(0, 3)], accent) { s.corner = Cfg.corners.indexOf(it) }
            Spacer(Modifier.height(8.dp))
            Text("Drag the cat anywhere. When you let go it snaps to the nearest corner.", color = Muted, fontSize = 12.sp)
        }
        Panel {
            ToggleRow("Fade when idle", "Dims the cat in its corner until you touch it", s.fade, accent) { s.fade = it }
            if (s.fade) SliderRow("Idle opacity · ${s.fadeAlpha}%", s.fadeAlpha.toFloat(), 10f..70f, accent) { s.fadeAlpha = it.toInt() }
        }
    }
}

// ---------- Cat style ----------

@Composable
fun CatStyleSheet(s: NekoSettings, onDone: () -> Unit) {
    val skin = s.currentSkin
    NekoSheet("Cat style", onDone) {
        Box(
            Modifier.fillMaxWidth().height(150.dp).drawBehind {
                drawCircle(Brush.radialGradient(listOf(skin.edge.copy(alpha = .45f), Color.Transparent)), size.minDimension * .6f, Offset(size.width / 2, size.height / 2))
            },
            contentAlignment = Alignment.Center
        ) { CatFace(true, skin.hue, Modifier.size(width = 150.dp, height = 128.dp)) }
        Spacer(Modifier.height(8.dp))
        Panel("Mood") { PillRow(Cfg.moods, Cfg.moods[s.mood], skin.edge) { s.mood = Cfg.moods.indexOf(it) } }
        Panel("Personality") { PillRow(Cfg.personas, Cfg.personas[s.persona], skin.edge) { s.persona = Cfg.personas.indexOf(it) } }
        Panel("Neon skin") {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Cfg.skins.forEachIndexed { i, sk ->
                    Box(
                        Modifier.size(38.dp).background(sk.edge, CircleShape)
                            .then(if (i == s.skin) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                            .clickable { s.skin = i }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Mood and personality change how Neko talks. The skin recolors the cat, the chat window and the app.", color = Muted, fontSize = 12.sp)
        }
    }
}

// ---------- AI brain ----------

@Composable
fun AiBrainSheet(s: NekoSettings, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val accent = s.currentSkin.edge
    fun open(url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    NekoSheet("AI brain", onDone) {
        Panel("Writing tone") { PillRow(Cfg.tones, s.tone, accent) { s.tone = it } }
        Panel("Reply language") { PillRow(Cfg.languages, s.lang, accent) { s.lang = it } }
        Panel("Reply length") { PillRow(Cfg.lengths, s.length, accent) { s.length = it } }
        Panel("Gemini (free)") {
            OutlinedTextField(s.key, { s.key = it.trim() }, label = { Text("API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(s.model, { s.model = it.trim() }, label = { Text("Model") }, singleLine = true,
                colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { open("https://aistudio.google.com/app/apikey") }) { Text("Get a free Gemini key", color = accent) }
        }
        Panel("TinyFish (optional)") {
            Text("Powers web search, link reading and web tasks.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(s.tfKey, { s.tfKey = it.trim() }, label = { Text("TinyFish key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { open("https://agent.tinyfish.ai/api-keys") }) { Text("Get a TinyFish key", color = accent) }
        }
        Text("Keys are stored on this phone only.", color = Muted, fontSize = 12.sp)
    }
}

// ---------- Smart features ----------

@Composable
fun SmartSheet(s: NekoSettings, onDone: () -> Unit) {
    val accent = s.currentSkin.edge
    NekoSheet("Smart features · ${s.featuresOn} of ${Cfg.features.size} on", onDone) {
        Panel {
            Cfg.features.forEach { f -> ToggleRow(f.title, f.sub, s.flag(f.key), accent) { s.setFlag(f.key, it) } }
        }
    }
}

// ---------- App control ----------

private class AppItem(val pkg: String, val label: String, val icon: ImageBitmap)

@Composable
fun AppControlSheet(s: NekoSettings, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val accent = s.currentSkin.edge
    var appList by remember { mutableStateOf<List<AppItem>?>(null) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val list = withContext(Dispatchers.Default) {
            val pm = ctx.packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.distinct()
                .filter { it != ctx.packageName }
                .mapNotNull { pkg ->
                    runCatching {
                        AppItem(pkg, pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(), pm.getApplicationIcon(pkg).toBitmap(72, 72).asImageBitmap())
                    }.getOrNull()
                }
                .sortedBy { it.label.lowercase() }
        }
        appList = list
        if (!s.prefs.contains("apps")) s.apps = list.map { it.pkg }.filter { it in Cfg.presetApps }.take(4).toSet()
    }

    NekoSheet("App control", onDone, scroll = false) {
        Panel {
            ToggleRow("Only in selected apps", "The bubble hides in every other app", s.only, accent) { s.only = it }
        }
        if (!s.only) {
            Text("Right now Neko shows up in every app. Turn the switch on to choose where the cat appears.", color = Muted, fontSize = 13.sp)
        } else {
            OutlinedTextField(query, { query = it }, label = { Text("Search apps") }, singleLine = true,
                colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            val shown = appList?.filter { it.label.contains(query, true) }
            if (shown == null) Text("Loading apps…", color = Muted, fontSize = 13.sp)
            else LazyColumn(Modifier.fillMaxWidth().height(360.dp)) {
                items(shown, key = { it.pkg }) { a ->
                    val on = a.pkg in s.apps
                    Row(
                        Modifier.fillMaxWidth().clickable { s.apps = if (on) s.apps - a.pkg else s.apps + a.pkg }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(a.icon, a.label, Modifier.size(36.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(a.label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Switch(
                            on, { s.apps = if (it) s.apps + a.pkg else s.apps - a.pkg },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = accent, uncheckedTrackColor = Color(0x22FFFFFF), uncheckedBorderColor = Color.Transparent)
                        )
                    }
                }
            }
        }
    }
}

// ---------- Privacy ----------

@Composable
fun PrivacySheet(s: NekoSettings, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val accent = s.currentSkin.edge
    NekoSheet("Privacy", onDone) {
        Panel {
            Text("Neko reads your screen only at the moment you tap the bubble. Password fields are always skipped, and nothing runs in the background.", color = Color.White, fontSize = 13.sp)
        }
        Panel {
            ToggleRow("Share screen text with the AI", "Off = Explain screen and context are disabled", s.flag("p_screen"), accent) { s.setFlag("p_screen", it) }
            ToggleRow("Hide emails, phones & card numbers", "Replaced with [email], [phone], [card] before sending", s.flag("p_mask"), accent) { s.setFlag("p_mask", it) }
            ToggleRow("Forget chat when I close it", "Off = the ✕ button keeps your conversation", s.flag("p_clear"), accent) { s.setFlag("p_clear", it) }
        }
        Panel("Your keys") {
            Text("API keys never leave this phone except in requests to Google and TinyFish.", color = Muted, fontSize = 12.sp)
            TextButton(onClick = { s.key = ""; s.tfKey = ""; Toast.makeText(ctx, "Keys erased", Toast.LENGTH_SHORT).show() }) { Text("Erase my keys", color = accent) }
        }
        Text("Free Gemini requests may be used by Google to improve its products. Avoid private screens, or turn off screen sharing above.", color = Muted, fontSize = 12.sp)
    }
}
