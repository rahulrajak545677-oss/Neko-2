package com.neko.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Reads Neko's replies aloud with Android text-to-speech. Main thread only. */
class Speaker(ctx: Context, private val langTag: () -> String) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var queued: Pair<String, () -> Unit>? = null
    private var onDone: (() -> Unit)? = null
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
        if (ready) queued?.let { (t, d) -> queued = null; speak(t, d) }
    }.also {
        it.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { val d = onDone; onDone = null; d?.invoke() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post { val d = onDone; onDone = null; d?.invoke() } }
        })
    }

    /** Emoji and markdown marks sound silly when spoken, so drop them. */
    private fun clean(t: String) = t.replace(Regex("[\\p{So}\\p{Cn}\\uFE0F\\u200d*_#`~]"), "").replace(Regex("\\s+"), " ").trim()

    fun speak(text: String, done: () -> Unit = {}) {
        val t = clean(text)
        if (t.isEmpty()) { done(); return }
        if (!ready) { queued = t to done; return }
        val r = tts.setLanguage(Locale.forLanguageTag(langTag()))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.language = Locale.getDefault()
        onDone = done
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "neko")
    }

    fun stop() { queued = null; onDone = null; if (ready) tts.stop() }
    fun destroy() { stop(); tts.shutdown() }
}
