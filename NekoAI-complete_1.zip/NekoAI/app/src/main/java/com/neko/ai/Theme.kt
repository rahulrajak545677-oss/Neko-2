package com.neko.ai

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Gen Z palette: deep void + neon lime + hot pink + violet + cyan
val Violet = Color(0xFF8B5CF6)
val Magenta = Color(0xFFE879F9)
val Pink = Color(0xFFFF4DCB)
val Lime = Color(0xFFC6FF3D)
val Cyan = Color(0xFF22D3EE)
val Void = Color(0xFF07040F)
val Muted = Color(0xFFA79CD6)
val Ink = Color(0xFF12081F)
val BotBubble = Color(0xFF211B33)
val UserBubble = Color(0xFF6D44F0)
val ChatBg = Color(0xF50B0716)
val Online = Color(0xFFB7B0DA)

val PinkViolet = Brush.linearGradient(listOf(Violet, Pink))
val LimeCyan = Brush.linearGradient(listOf(Lime, Cyan))

/** Neo-brutalist "sticker": hard offset shadow + chunky outline. */
fun Modifier.sticker(fill: Color, shadow: Color = Color.Black, radius: Dp = 16.dp, offset: Dp = 3.dp): Modifier =
    this.drawBehind {
        val o = offset.toPx()
        drawRoundRect(shadow, Offset(o, o), size, CornerRadius(radius.toPx()))
    }
        .background(fill, RoundedCornerShape(radius))
        .border(1.5.dp, Color.Black, RoundedCornerShape(radius))

@Composable
fun rememberHaptic(enabled: Boolean = true): () -> Unit {
    val v = LocalView.current
    return { if (enabled) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
}
