package com.neko.ai

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.delay
import kotlin.math.abs

/** Foreground service: corner-snapping cat bubble + the floating chat window. */
class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var owner: OverlayOwner
    private var bubble: BubbleView? = null
    private var chat: ComposeView? = null
    private var chatLp: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("neko", MODE_PRIVATE) }
    private lateinit var chatState: ChatState
    private lateinit var voice: VoiceInput
    private lateinit var speaker: Speaker

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "size", "skin", "corner", "fade", "fadeAlpha" -> bubble?.applyPrefs()
            "only", "apps" -> updateBubbleVisibility()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        owner = OverlayOwner()
        val ai = AiHelper(prefs)
        voice = VoiceInput(this) { ai.langTag() }
        speaker = Speaker(this) { ai.langTag() }
        chatState = newChatState()
        goForeground()
        addBubble()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        NekoAccessibilityService.onForeground = { updateBubbleVisibility() }
        updateBubbleVisibility()
    }

    /** "Only in selected apps": hide the bubble everywhere else. Also hidden while the chat is open. */
    private fun updateBubbleVisibility() {
        val b = bubble ?: return
        val only = prefs.getBoolean("only", false)
        val fg = NekoAccessibilityService.foreground
        val allowed = !only || fg == null || (prefs.getStringSet("apps", emptySet()) ?: emptySet()).contains(fg)
        val show = chat == null && allowed
        if (show && b.visibility != View.VISIBLE) { b.visibility = View.VISIBLE; b.reveal() }
        else if (!show) b.visibility = View.GONE
    }

    private fun newChatState() = ChatState(AiHelper(prefs), capture = { captureScreen() })

    /** Hide Neko's own windows so they don't appear in the screenshot, grab the screen, then bring them back. */
    private suspend fun captureScreen(): Bitmap {
        val v = chat
        v?.visibility = View.INVISIBLE
        try {
            delay(350)   // let the compositor draw a frame without the chat
            return NekoAccessibilityService.capture()
        } finally { v?.visibility = View.VISIBLE }
    }

    private fun goForeground() {
        val ch = "neko"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Neko AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Neko is online")
            .setContentText("Tap the cat bubble to chat").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (Build.VERSION.SDK_INT >= 34) {
            // The microphone type is only allowed once RECORD_AUDIO is granted; the app restarts us after the user allows it.
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, type)
        } else startForeground(1, n)
    }

    private fun addBubble() {
        val w = (prefs.getInt("size", 64) * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            w, (w * 0.85f).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        val b = BubbleView(this, lp, wm, prefs) { showChat() }
        b.placeAtCorner(prefs.getInt("corner", BubbleView.TOP_RIGHT))
        bubble = b
        wm.addView(b, lp)
        b.scheduleFade()
    }

    private fun showChat() {
        if (chat != null) return
        NekoAccessibilityService.snapshot()   // read the screen now, while the other app is in front
        val dm = resources.displayMetrics
        val margin = (12 * dm.density).toInt()
        val lp = WindowManager.LayoutParams(
            minOf(dm.widthPixels - margin * 2, (380 * dm.density).toInt()), (dm.heightPixels * 0.55f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = margin; y = margin
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent {
                ChatWindow(
                    state = chatState,
                    voice = voice,
                    speaker = speaker,
                    skin = Cfg.skin(prefs.getInt("skin", 0)),
                    onMinimize = { hideChat() },
                    onClose = { if (prefs.flag("p_clear")) chatState = newChatState(); hideChat() },
                    onWantInput = { makeChatFocusable() }
                )
            }
        }
        chat = view; chatLp = lp
        wm.addView(view, lp)
        bubble?.visibility = View.GONE
    }

    /** Overlay windows only get a keyboard once FLAG_NOT_FOCUSABLE is cleared. */
    private fun makeChatFocusable() {
        val lp = chatLp ?: return
        val v = chat ?: return
        if (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE != 0) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            wm.updateViewLayout(v, lp)
        }
    }

    private fun hideChat() {
        chat?.let { it.disposeComposition(); wm.removeView(it) }
        chat = null; chatLp = null
        updateBubbleVisibility()
        bubble?.reveal()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bubble?.post { bubble?.snapNow() }   // screen rotated: re-seat the bubble in its corner
    }

    override fun onDestroy() {
        hideChat()
        bubble?.let { it.stop(); wm.removeView(it) }
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        NekoAccessibilityService.onForeground = null
        voice.destroy()
        speaker.destroy()
        owner.destroy()
        super.onDestroy()
    }
}

/**
 * The cat bubble. Drag it anywhere; on release it springs to the nearest screen corner (like Assistive Touch),
 * fades out after a moment of not being used, and lights back up when touched.
 */
@SuppressLint("ViewConstructor")
class BubbleView(
    ctx: Context, private val lp: WindowManager.LayoutParams,
    private val wm: WindowManager, private val prefs: android.content.SharedPreferences,
    private val onTap: () -> Unit
) : View(ctx) {
    companion object {
        const val TOP_LEFT = 0; const val TOP_RIGHT = 1; const val BOTTOM_LEFT = 2; const val BOTTOM_RIGHT = 3
        private const val IDLE_DELAY_MS = 2500L
    }

    private val density = ctx.resources.displayMetrics.density
    private val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.neko_cat)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var fadeEnabled = prefs.getBoolean("fade", true)
    private var idleAlpha = prefs.getInt("fadeAlpha", 30) / 100f
    private val fadeOut = Runnable { if (fadeEnabled) animate().alpha(idleAlpha).setDuration(700).start() }
    private var snap: ValueAnimator? = null
    private var velocity: VelocityTracker? = null
    private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
    private var moved = false
    private var corner = prefs.getInt("corner", TOP_RIGHT)

    init { applyHue() }

    private fun applyHue() {
        paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(Cfg.hueMatrix(Cfg.skin(prefs.getInt("skin", 0)).hue)))
    }

    /** Called live when Bubble look / Cat style settings change. */
    fun applyPrefs() {
        applyHue()
        fadeEnabled = prefs.getBoolean("fade", true)
        idleAlpha = prefs.getInt("fadeAlpha", 30) / 100f
        val w = (prefs.getInt("size", 64) * density).toInt()
        val c = prefs.getInt("corner", corner)
        if (w != lp.width) { lp.width = w; lp.height = (w * 0.85f).toInt(); placeAtCorner(c); if (isAttachedToWindow) wm.updateViewLayout(this, lp) }
        else if (c != corner) animateTo(c, 0f, 0f)
        invalidate()
        reveal()
    }

    override fun onDraw(canvas: Canvas) { canvas.drawBitmap(bmp, null, Rect(0, 0, width, height), paint) }

    // ---- geometry ----
    @Suppress("DEPRECATION")
    private fun screen(): Point =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.let { Point(it.width(), it.height()) }
        else Point().also { wm.defaultDisplay.getRealSize(it) }

    private fun sysDimen(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun cornerXY(c: Int): Point {
        val s = screen()
        val side = (6 * density).toInt()
        val top = sysDimen("status_bar_height") + (10 * density).toInt()
        val bottom = sysDimen("navigation_bar_height") + (14 * density).toInt()
        val right = c == TOP_RIGHT || c == BOTTOM_RIGHT
        val bottomRow = c == BOTTOM_LEFT || c == BOTTOM_RIGHT
        return Point(
            if (right) s.x - lp.width - side else side,
            if (bottomRow) s.y - lp.height - bottom else top
        )
    }

    fun placeAtCorner(c: Int) { corner = c; val p = cornerXY(c); lp.x = p.x; lp.y = p.y }

    fun snapNow() { animateTo(corner, 0f, 0f) }

    private fun nearestCorner(vx: Float, vy: Float): Int {
        val s = screen()
        val cx = lp.x + lp.width / 2f + vx * 0.12f   // a flick carries the bubble a bit further
        val cy = lp.y + lp.height / 2f + vy * 0.12f
        val right = cx > s.x / 2f; val bottom = cy > s.y / 2f
        return when { !right && !bottom -> TOP_LEFT; right && !bottom -> TOP_RIGHT; !right -> BOTTOM_LEFT; else -> BOTTOM_RIGHT }
    }

    private fun animateTo(c: Int, vx: Float, vy: Float) {
        corner = c
        prefs.edit().putInt("corner", c).apply()
        val to = cornerXY(c); val fx = lp.x; val fy = lp.y
        snap?.cancel()
        snap = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 320; interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                val t = it.animatedValue as Float
                lp.x = (fx + (to.x - fx) * t).toInt(); lp.y = (fy + (to.y - fy) * t).toInt()
                if (isAttachedToWindow) wm.updateViewLayout(this@BubbleView, lp)
            }
            start()
        }
    }

    // ---- fade ----
    fun reveal() { handler.removeCallbacks(fadeOut); animate().cancel(); alpha = 1f; scheduleFade() }
    fun scheduleFade() { handler.removeCallbacks(fadeOut); if (fadeEnabled) handler.postDelayed(fadeOut, IDLE_DELAY_MS) }
    fun stop() { handler.removeCallbacksAndMessages(null); snap?.cancel() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(fadeOut); animate().cancel(); animate().alpha(1f).setDuration(120).start()
                snap?.cancel()
                velocity?.recycle(); velocity = VelocityTracker.obtain()
                downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(e)
                val dx = e.rawX - downX; val dy = e.rawY - downY
                if (abs(dx) > 8 * density || abs(dy) > 8 * density) moved = true
                if (moved) {
                    val s = screen()
                    lp.x = (startX + dx).toInt().coerceIn(0, s.x - lp.width)
                    lp.y = (startY + dy).toInt().coerceIn(0, s.y - lp.height)
                    wm.updateViewLayout(this, lp)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.action == MotionEvent.ACTION_UP && !moved) { onTap() }
                else if (moved) {
                    velocity?.computeCurrentVelocity(1000)
                    animateTo(nearestCorner(velocity?.xVelocity ?: 0f, velocity?.yVelocity ?: 0f), 0f, 0f)
                }
                velocity?.recycle(); velocity = null
                scheduleFade()
            }
        }
        return true
    }
}
