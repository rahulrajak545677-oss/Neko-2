package com.neko.ai

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/** A failure with a message that is safe to show in the chat. */
class NekoException(message: String) : Exception(message)

/** Free Google Gemini API (key from aistudio.google.com/app/apikey). The key never leaves the phone except in calls to Google. */
object GeminiClient {
    const val DEFAULT_MODEL = "gemini-2.5-flash-lite"
    private const val SYSTEM = "You are Neko AI, a friendly cat assistant that floats over the user's apps. " +
        "If screen text or a screenshot is provided, use it as context."

    private fun jpegBase64(src: Bitmap): String {
        val scale = 1024f / max(src.width, src.height)
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun ask(
        key: String, model: String, prompt: String, screen: String?, style: String = "", image: Bitmap? = null,
        history: List<Pair<Boolean, String>> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val text = if (screen.isNullOrBlank()) prompt else "Screen text:\n${screen.take(6000)}\n\nRequest: $prompt"
        val parts = JSONArray()
        if (image != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", jpegBase64(image))))
        parts.put(JSONObject().put("text", text))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM + style))))
            .put("contents", JSONArray().apply {
                // earlier turns of the chat: (true = user, false = Neko)
                history.forEach { (mine, t) ->
                    put(JSONObject().put("role", if (mine) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", t))))
                }
                put(JSONObject().put("role", "user").put("parts", parts))
            })
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.connectTimeout = 15000; conn.readTimeout = 45000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val raw = ((if (code in 200..299) conn.inputStream else conn.errorStream) ?: return@withContext "Gemini error $code.")
                .bufferedReader().readText()
            if (code !in 200..299) throw NekoException(
                when (code) {
                    429 -> "Free limit reached for now. Wait a minute and try again."
                    400, 403 -> "Gemini rejected the request. Check your API key."
                    404 -> "Model “$model” wasn’t found. Change the model name in AI keys."
                    else -> "Gemini error $code."
                }
            )
            val cands = JSONObject(raw).optJSONArray("candidates")
            val ps = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw NekoException("Gemini didn’t answer that one (it may have been blocked). Try rephrasing.")
            (0 until ps.length()).joinToString("") { ps.getJSONObject(it).optString("text") }.trim()
                .ifBlank { throw NekoException("Gemini sent an empty answer. Try again.") }
        } finally { conn.disconnect() }
    }
}

class AiHelper(private val prefs: SharedPreferences) {
    fun tfKey(): String = prefs.getString("tfKey", "").orEmpty()
    fun flag(k: String) = prefs.flag(k)
    fun mood(): Int = prefs.getInt("mood", 0)

    /** Language tag for voice input, matching the reply language setting. */
    fun langTag(): String = when (prefs.getString("lang", "English")) {
        "Hindi" -> "hi-IN"; "Hinglish" -> "en-IN"; "Spanish" -> "es-ES"; "French" -> "fr-FR"; "Arabic" -> "ar-SA"; else -> "en-US"
    }

    private fun persona(): String = when (prefs.getInt("persona", 0)) {
        1 -> " Personality: serious and precise, no jokes, no emojis."
        2 -> " Personality: witty and playful, gentle jokes allowed."
        3 -> " Personality: an encouraging coach; finish with a clear next step."
        else -> " Personality: cute and playful cat; an occasional paw or cat emoji is fine."
    }

    private fun mood(i: Int): String = when (i) {
        1 -> " Mood: sleepy and calm, relaxed pace (stay clear and correct)."
        2 -> " Mood: very enthusiastic, upbeat."
        3 -> " Mood: thoughtful; reason briefly before answering."
        else -> " Mood: cheerful."
    }

    private fun length(): String = when (prefs.getString("length", "Normal")) {
        "Short" -> " Keep answers under 40 words."
        "Detailed" -> " Give thorough answers (up to 200 words) when useful."
        else -> " Be concise (under 80 words unless asked)."
    }

    /**
     * Returns the answer, or throws NekoException with a friendly message (so errors are never mistaken for answers).
     * [plain] = true for text rewrites: only tone and language apply, no personality, mood or length limit.
     */
    private val friendStyle = " You are chatting like a warm, close friend in everyday life: natural and casual, " +
        "usually 1 to 3 short sentences. React to how the person feels first. Ask one friendly follow-up question when it fits. " +
        "Remember what they told you earlier in this chat. Simple words, no bullet lists, never lecture or sound like customer support."

    suspend fun ask(
        prompt: String, screen: String?, image: Bitmap? = null, plain: Boolean = false,
        history: List<Pair<Boolean, String>> = emptyList(), friend: Boolean = false
    ): String {
        val key = prefs.getString("key", "").orEmpty()
        if (key.isBlank()) throw NekoException("Add your free Gemini key first: open AI brain in the Neko app.")
        var style = " Tone: ${prefs.getString("tone", "Friendly")}. Reply in ${prefs.getString("lang", "English")}."
        if (!plain) style += length() + persona() + mood(mood()) + (if (friend) friendStyle else "")
        return GeminiClient.ask(key, prefs.getString("model", GeminiClient.DEFAULT_MODEL).orEmpty(), prompt, screen, style, image, history)
    }
}
