package com.neko.ai

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * [capture] hides Neko's windows, grabs the screen and returns it (provided by BubbleService).
 * [draft], [screenText] and [apply] default to the accessibility service; Try Neko swaps in its sample draft.
 */
class ChatState(
    private val ai: AiHelper,
    private val capture: suspend () -> Bitmap,
    private val draft: () -> String? = { NekoAccessibilityService.draft },
    private val screenText: () -> String? = { NekoAccessibilityService.screen },
    private val apply: (String) -> Boolean = { NekoAccessibilityService.setDraft(it) }
) {
    val msgs = mutableStateListOf(Msg(false, greeting(ai.mood())))
    fun flag(k: String) = ai.flag(k)
    var typing by mutableStateOf(false)
    var replyId by mutableIntStateOf(0)       // bumps on every successful reply; the window uses it to speak
        private set
    var lastReply = ""
        private set
    private val turns = mutableListOf<Pair<Boolean, String>>()   // chat memory for Friend chat (user, Neko)

    private val starters = linkedMapOf(
        "☀️ Say good morning" to "Good morning Neko!",
        "😂 Tell me a joke" to "Tell me a joke!",
        "💜 Cheer me up" to "I'm feeling a bit down today. Can you cheer me up?",
        "🗣️ Practice English" to "Let's practice English conversation. Talk to me casually and gently correct my mistakes.",
        "🍜 What should I eat?" to "I can't decide what to eat today. Help me choose!"
    )
    private fun remember(q: String, a: String) {
        turns.add(true to q); turns.add(false to a)
        while (turns.size > 16) { turns.removeAt(0); turns.removeAt(0) }   // keep pairs so roles alternate
    }
    var attached by mutableStateOf<Bitmap?>(null)          // screenshot waiting to be sent with the next message
        private set
    private var pending by mutableStateOf<String?>(null)   // last rewrite, waiting to be applied
    private var mode by mutableStateOf<String?>(null)      // "search" or "task": the next message is the query

    private val urlRe = Regex("https?://\\S+")
    private val needKey = "Add your TinyFish key first: open AI brain in the Neko app."

    fun chips(): List<String> {
        if (!flag("f_chips")) return emptyList()
        return buildList {
            if (flag("f_friend") && turns.isEmpty()) addAll(starters.keys)
            if (flag("f_write")) { add("Make it professional"); add("Make it shorter"); add("Add emojis ✨") }
            if (flag("f_explain")) add("Explain screen")
            if (flag("f_shot")) add("📸 Look at screen")
            if (flag("f_search")) add("🔎 Search the web")
            if (flag("f_task")) add("🌐 Web task")
            if (pending != null && flag("f_apply")) add("Apply to text field")
        }
    }

    fun clearAttachment() { attached = null }

    /** 📷 button: grab the screen and hold it until the user sends their question. */
    suspend fun attachScreenshot() {
        try {
            attached = capture()
        } catch (e: Exception) {
            msgs.add(Msg(false, e.message ?: "Couldn’t capture the screen."))
        }
    }

    suspend fun send(text: String) {
        val shot = attached; attached = null
        val q = text.ifBlank { "What’s on my screen? Help me with it." }
        msgs.add(Msg(true, q, shot?.let { thumb(it) }))
        val m = mode; mode = null
        reply {
            when {
                shot != null -> ai.ask(q, screenText(), shot)
                m == "search" -> search(q)
                m == "task" -> task(q)
                urlRe.containsMatchIn(q) && flag("f_links") -> readPage(q)   // a link in your message: Neko reads the page
                flag("f_friend") -> ai.ask(q, null, history = turns.toList(), friend = true).also { remember(q, it) }
                else -> ai.ask(q, screenText())
            }
        }
    }

    suspend fun onChip(c: String) {
        starters[c]?.let { send(it); return }
        msgs.add(Msg(true, c))
        when {
            c.startsWith("🔎") -> { mode = "search"; msgs.add(Msg(false, "What should I search for?")) }
            c.startsWith("🌐") -> {
                mode = "task"
                msgs.add(Msg(false, "Tell me the website and what to do, like: example.com find the cheapest plan"))
            }
            c.startsWith("Apply") -> reply {
                val ok = pending?.let(apply) == true
                if (ok) { pending = null; "Done! I replaced your text. ✅" } else "I couldn’t edit that field. Copy the text above instead."
            }
            c.startsWith("📸") -> reply {
                val shot = capture()
                ai.ask("Explain what is on my screen and what I can do here.", null, shot)
            }
            c.startsWith("Explain") -> reply {
                if (!flag("p_screen")) return@reply "Screen sharing is off. You can turn it on in Privacy."
                ai.ask("Explain what is on my screen and what I can do here.", screenText())
            }
            else -> reply {
                val d = draft()
                if (d.isNullOrBlank()) return@reply "I can’t see your draft. Tap into the text box, then tap my bubble and try again."
                val style = when {
                    c.contains("profess", true) -> "more professional"
                    c.contains("short", true) -> "shorter"
                    else -> "friendlier, with fitting emojis"
                }
                ai.ask("Rewrite this text to be $style. Return only the rewritten text.\n\n$d", null, plain = true).also { pending = it }
            }
        }
    }

    private fun thumb(b: Bitmap): Bitmap {
        val w = 360; val h = (b.height * (w.toFloat() / b.width)).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(b, w, h, true)
    }

    // TinyFish gets the data, Gemini turns it into a short answer.
    private suspend fun search(q: String): String {
        val k = ai.tfKey().ifBlank { return needKey }
        val res = TinyFishClient.search(k, q)
        if (res.isBlank()) return "I found no results for that."
        return ai.ask("Web results:\n$res\n\nUsing only these results, answer: $q\nName the top 2 sources.", null)
    }

    private suspend fun readPage(text: String): String {
        val k = ai.tfKey().ifBlank { return needKey }
        val url = urlRe.find(text)!!.value
        return ai.ask("Page content:\n${TinyFishClient.fetch(k, url)}\n\nThe user asked: $text", null)
    }

    private suspend fun task(text: String): String {
        val k = ai.tfKey().ifBlank { return needKey }
        val parts = text.trim().split(" ", limit = 2)
        val url = parts[0].let { if (it.startsWith("http")) it else "https://$it" }
        val goal = parts.getOrElse(1) { "Summarize this page" }
        val raw = TinyFishClient.agent(k, url, goal)
        return ai.ask("A web agent just did this task: $goal\nRaw result:\n$raw\n\nExplain the result briefly.", null)
    }

    private fun greeting(mood: Int) = when (mood) {
        1 -> "Hi… *yawn* how can I help? 😴"
        2 -> "Hi!! What are we doing today? ✨"
        3 -> "Hi. What are we figuring out? 🤔"
        else -> "Hi! How can I help you?"
    }

    private suspend fun reply(block: suspend () -> String) {
        typing = true
        var ok = true
        val r = try { block() } catch (e: Exception) { ok = false; e.message ?: "Something went wrong." }
        typing = false
        msgs.add(Msg(false, r))
        if (ok) { lastReply = r; replyId++ }
    }
}
