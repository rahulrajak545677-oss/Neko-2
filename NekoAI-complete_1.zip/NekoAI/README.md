# Neko AI

A floating cat assistant for Android: tap the cat bubble over any app, and Neko reads the screen, fixes your writing, looks at screenshots, listens to your voice and answers questions.
Uses the **free Google Gemini API** for answers and (optionally) **TinyFish** for web search, page reading and web tasks.

## Run it
1. Install Android Studio (Ladybug or newer). Open this folder (`NekoAI`) and let Gradle sync (it creates the Gradle wrapper for you).
2. Run on a phone with Android 8.0+ (Android 11+ for screenshots). A real device is best; overlays are limited on emulators.
3. In the app tap **Grant all permissions** and follow the steps: Overlay, Mic, then turn on *Neko AI* in Accessibility settings.
4. Open **AI brain** and paste a free Gemini key from https://aistudio.google.com/app/apikey (optional: a TinyFish key from https://agent.tinyfish.ai/api-keys).
5. Tap the cat to wake Neko, then tap the floating cat in any app. Or try everything safely in **Try Neko**.

## Screens
- **Try Neko** – a sample draft and the real chat window, inside the app.
- **Bubble look** – size, start corner, fade when idle, and **Cat style** (mood, personality, neon skin).
- **AI brain** – tone, language, reply length, keys, model.
- **Smart features** – 12 switches (friend chat, speak replies, writing, apply, explain, screenshots, voice, search, links, web tasks, chips, haptics).
- **App control** – show the bubble only in the apps you pick.
- **Privacy** – screen sharing, masking of emails/phones/cards, forget-on-close, erase keys.

## Friend chat and Talk mode
- **Friend chat** (on by default): normal messages get a warm, casual, daily-life style and Neko remembers the conversation until you close the chat. Starter chips like "Say good morning" or "Cheer me up" show on a fresh chat.
- **Speak replies** (Smart features): Neko reads answers aloud.
- **Talk mode** (headset button in the chat header): hands-free loop. You speak, Neko answers out loud, then listens again. Tap the headset again to stop.

## How the bubble behaves
Drag it anywhere; on release it snaps to the nearest corner, fades when idle, and lights up when touched.

## Notes
- Not compiled by the author: expect to fix a small error or two on first build.
- Free Gemini requests may be used by Google to improve its products. Use Privacy to stop sharing screen text.
- Keys are stored on the phone only. If you ever publish this app, move them to a backend, and review Google Play's policy for accessibility services.
- The TinyFish *Agent* endpoint (`/v1/automation/run`) was not verified; Search and Fetch match the docs.

## Build the APK on GitHub
1. Create a new GitHub repository and push this folder to it (branch `main`).
2. Open the **Actions** tab, then **Build APK**. It runs on every push, or press **Run workflow**.
3. When it turns green, open the run and download **NekoAI-debug-apk** from *Artifacts*. Unzip it and install `NekoAI-debug.apk`.
4. To publish a download link: `git tag v0.2 && git push origin v0.2`. The APK appears under **Releases**.
